import RouterComp from "./components/RouterComp";

function App() {
  return (
    <>
    <RouterComp></RouterComp>
    </>
  )
}

export default App;
