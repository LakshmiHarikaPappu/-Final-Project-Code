import React from "react";
import { withRouter } from "react-router";
import axios from "axios";

import Select from "react-dropdown-select";
import AppointmentAccordian from "./BookAppAcc";

class ViewAppointments extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userId: localStorage.getItem("userId"),
      userRole: localStorage.getItem("userRole"),
      selectedLocation: "",
      appointmentList: [],
    };
  }

  componentWillMount() {
    let reqUrl = `http://localhost:8080/booking/history/user/${localStorage.getItem(
      "userId"
    )}`;
    axios.get(reqUrl).then((res) => {
      this.setState({
        appointmentList: res.data.history,
      });
    });
  }

  refreshData = () => {
    let reqUrl = `http://localhost:8080/booking/history/user/${localStorage.getItem(
      "userId"
    )}`;
    axios.get(reqUrl).then((res) => {
      this.setState({
        appointmentList: res.data.history,
      });
    });
  };

  handleAddLocation = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/addLocation");
  };

  handleManageAppointments = () => {
    const {
      history: { push },
    } = this.props;
    push("/manageAppointments");
  };

  handleLogout = () => {
    localStorage.removeItem("userId");

    const {
      history: { push },
    } = this.props;
    push("/");
  };

  handleBookingAppointment = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/bookingAppointment");
  };

  handleViewAppointments = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/viewAppointments");
  };

  handleHome = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/userhome");
  };

  handleLocationList = (data) => {
    this.setState({
      selectedLocation: data,
    });
  };

  render() {
    const {
      userId,
      userRole,
      projectDatas,
      locationList,
      selectedLocation,
      appointmentList,
    } = this.state;
    return (
      <div
        className=" flex flex-col"
        style={{ backgroundColor: "aliceBlueBlue", minHeight: "100vh" }}
      >
        <div
          style={{
            backgroundColor: "#0c2074",
            display: "flex",
            padding: "12px",
            color: "white",
          }}
        >
          <div style={{ display: "flex", flexGrow: "1" }}>
            <div
              style={{
                fontSize: "24px",
                fontWeight: "600",
                width: "100%",
                display: "flex",
                padding: "20px",
                alignItems: "center",
                color: "white",
              }}
            >
              BANK APPOINTMENT BOOKING
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 50,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleHome}
            >
              Home
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 50,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleBookingAppointment}
            >
              Book Appointment
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 150,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleViewAppointments}
            >
              View Appointments
            </div>
            <button
              style={{
                background: "white",
                color: "#0c2074",
                height: 35,
                width: 80,
                alignItems: "center",
                borderRadius: 8,
                marginRight: 20,
              }}
              onClick={this.handleLogout}
            >
              Logout
            </button>
          </div>
        </div>

        <div style={{ marginTop: 50 }}>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              marginTop: 50,
            }}
          >
            {appointmentList.map((data, idx) => {
              return (
                <AppointmentAccordian
                  refreshData={this.refreshData}
                  data={data}
                  idx={idx}
                />
              );
            })}
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(ViewAppointments);
