import React from "react";
import { withRouter } from "react-router";
import axios from "axios";

import Select from "react-dropdown-select";
import LocationAccordian from "./BookAppLocAcc";

const url = "http://localhost:8080/booking/location/all";
class ViewLocation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userId: localStorage.getItem("userId"),
      userRole: localStorage.getItem("userRole"),
      locationDetails: [],
    };
  }

  componentWillMount() {
    axios.get(url).then((res) => {
      this.setState({
        locationDetails: res.data.locationDetails,
      });
    });
  }

  refreshData = () => {
    axios.get(url).then((res) => {
      this.setState({
        locationDetails: res.data.locationDetails,
      });
    });
  };

  handleAddLocation = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/addLocation");
  };

  handleManageAppointments = () => {
    const {
      history: { push },
    } = this.props;
    push("/manageAppointments");
  };

  handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userRole");
    const {
      history: { push },
    } = this.props;
    push("/");
  };

  handleNewApplication = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/applicationForm");
  };

  handleViewApplication = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/viewApplication");
  };

  handleHome = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/home");
  };

  handleViewLocation = () => {
    const {
      history: { push },
    } = this.props;
    push("/viewLocation");
  };

  handleLocationList = (data) => {
    this.setState({
      selectedLocation: data,
    });
  };

  handleLogout = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/");
  };

  updateInProjectArray = (projectData) => {
    this.setState({
      projectDatas: this.state.projectDatas.filter(function (data) {
        return data.projectId !== projectData.projectId;
      }),
    });
  };

  updateProjectArrayStatus = (index, status) => {
    this.setState(({ projectDatas }) => ({
      projectDatas: [
        ...projectDatas.slice(0, index),
        {
          ...projectDatas[index],
          state: status,
        },
        ...projectDatas.slice(index + 1),
      ],
    }));
  };

  render() {
    const {
      userId,
      userRole,
      projectDatas,
      locationList,
      selectedLocation,
      locationDetails,
    } = this.state;
    return (
      <div
        className=" flex flex-col"
        style={{ backgroundColor: "aliceBlueBlue", minHeight: "100vh" }}
      >
        <div
          style={{
            backgroundColor: "#0c2074",
            display: "flex",
            padding: "12px",
            color: "white",
          }}
        >
          <div style={{ display: "flex", flexGrow: "1" }}>
            <div
              style={{
                fontSize: "24px",
                fontWeight: "600",
                width: "100%",
                display: "flex",
                padding: "20px",
                alignItems: "center",
                color: "white",
              }}
            >
              BANK APPOINTMENT BOOKING
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 50,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleHome}
            >
              Home
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 50,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleAddLocation}
            >
              Add Location
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 150,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleViewLocation}
            >
              View Location
            </div>
            <button
              style={{
                background: "white",
                color: "#0c2074",
                height: 35,
                width: 80,
                alignItems: "center",
                borderRadius: 8,
                marginRight: 20,
              }}
              onClick={this.handleLogout}
            >
              Logout
            </button>
          </div>
        </div>

        <div style={{ marginTop: 50 }}>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              marginTop: 50,
            }}
          >
            {locationDetails.map((loc) => {
              const location = loc.location;
              return (
                <LocationAccordian
                  data={location}
                  updateLocationData={this.refreshData}
                />
              );
            })}
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(ViewLocation);
