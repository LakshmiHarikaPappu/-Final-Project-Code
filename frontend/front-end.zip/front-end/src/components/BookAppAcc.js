import React from "react";
import { withRouter } from "react-router";
import axios from "axios";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContentText from "@mui/material/DialogContentText";
import TextField from "@mui/material/TextField";
import Select from "react-dropdown-select";
import Button from "@mui/material/Button";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import HolidaysList from "./BookAppHldysList";

const availableTimeSlot = "http://localhost:8080/booking/appointment/timeslot";
class AppointmentAccordian extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      openCancelDailog: false,
      selectedDate: new Date("2022-12-01T21:11:54"),
      timeSlotList: [],
      open: false,
      bookingTime: "",
      bookingDate: "2022-12-01",
    };
  }

  componentDidMount() {
    const { data } = this.props;
    const timeList = [];
    const json = {
      locationId: data.locationId,
      appointmentType: data.appointmentType,
      bookingDate: "2022-12-01",
    };
    axios.post(availableTimeSlot, json).then((res) => {
      let timeslotlist = res.data.availableSlot;
      timeslotlist.forEach((a) => {
        let obj = {};
        obj["label"] =
          a < 12 ? a + " - AM" : a === 12 ? a + " - PM" : a - 12 + " - PM";
        obj["value"] = a;
        timeList.push(obj);
      });
      this.setState({
        displayTimeslot: true,
        timeSlotList: timeList,
      });
    });
  }

  disabledDate = (current) => {
    let disabledDates = HolidaysList;

    return disabledDates.includes(current.format("YYYY-MM-DD"));
  };

  openReseduleDialog = () => {
    this.setState({
      open: true,
    });
  };

  handleCancel = (e) => {
    e.stopPropagation();
    this.setState({ openCancelDailog: true });
  };

  handleCancelClose = (e) => {
    e.stopPropagation();
    this.setState({ open: false });
  };

  handleDelete = (id) => {
    let reqUrl = `http://localhost:8080/booking/delete/appointment/${id}`;
    axios.delete(reqUrl).then((res) => {
      alert("Appointment Cancelled");
      this.props.refreshData();
    });
  };
  handleReschedule = (id) => {
    const { data } = this.props;
    const { bookingDate, bookingTime } = this.state;
    const reqJson = {
      id: data.id,
      locationId: data.locationId,
      userId: data.userId,
      purpose: data.purpose,
      bookingUserName: data.bookingUserName,
      bookingPhoneNumber: data.bookingPhoneNumber,
      bookingEmail: data.bookingEmail,
      bookingDate: bookingDate,
      startTime: bookingTime,
      bookingAddress: data.bookingAddress,
      appointmentType: data.appointmentType,
    };
    let reqUrl = `http://localhost:8080/booking/user/updateBooking`;
    axios.post(reqUrl, reqJson).then((res) => {
      this.setState({
        open: false,
        timeSlotList: [],
        bookingDate: "2022-12-01",
      });
      alert("Appointment rescheduled");
      this.props.refreshData();
    });
  };
  handleTimeslots = (data) => {
    let bookingTime = data[0].value;
    this.setState({
      selectedTimeSlot: data,
      bookingTime: bookingTime,
    });
  };
  handleDateChange = (date) => {
    const { data } = this.props;
    const timeList = [];
    let datelength = date.$D < 9 ? "0" + date.$D : date.$D;
    const dateFormat = date.$y + "-" + (date.$M + 1) + "-" + datelength;
    const json = {
      locationId: data.locationId,
      appointmentType: data.appointmentType,
      bookingDate: dateFormat,
    };
    axios.post(availableTimeSlot, json).then((res) => {
      let timeslotlist = res.data.availableSlot;
      timeslotlist.forEach((a) => {
        let obj = {};
        obj["label"] =
          a < 12 ? a + " - AM" : a === 12 ? a + " - PM" : a - 12 + " - PM";
        obj["value"] = a;
        timeList.push(obj);
      });
      this.setState({
        selectedDate: date,
        bookingDate: dateFormat,
        timeSlotList: timeList,
      });
    });
  };
  render() {
    const { data, idx } = this.props;
    const { selectedDate, timeSlotList, open } = this.state;
    let bookingtime =
      data.startTime < 12
        ? data.startTime + " - AM"
        : data.startTime === 12
        ? data.startTime + " - PM"
        : data.startTime - 12 + " - PM";
    let bookingDateandtime = data.bookingDate + "(" + bookingtime + ")";
    const date = new Date(data.bookingDate);
    console.log(data);
    console.log(date);
    console.log(Date.now());
    let isShowCancel = date < Date.now() ? false : true;
    return (
      <Accordion style={{ width: "50%" }}>
        <AccordionSummary
          style={{ alignItems: "center" }}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography
            style={{ fontSize: "17px", fontWeight: "600" }}
            sx={{ width: "50%", flexShrink: 0 }}
          >
            Appointment No: {idx + 1}
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography style={{ fontSize: "17px", marginBottom: "12px" }}>
            Location Name : {data.locationName}
          </Typography>
          <Typography style={{ fontSize: "17px", marginBottom: "12px" }}>
            Booking User Name : {data.bookingUserName}
          </Typography>
          <Typography style={{ fontSize: "17px", marginBottom: "12px" }}>
            Purpose of Appointment : {data.purpose}
          </Typography>
          <Typography
            style={{ fontSize: "17px", marginBottom: "12px" }}
            sx={{ width: "50%", flexShrink: 0 }}
          >
            Booking Date & Time : {bookingDateandtime}
          </Typography>

          {isShowCancel && (
            <Typography style={{ display: "flex" }}>
              <div style={{ display: "flex", flexGrow: "1" }}>
                <button
                  style={{
                    background: "#0c2074",
                    color: "white",
                    height: 35,
                    width: 80,
                    alignItems: "center",
                    borderRadius: 8,
                    marginRight: 20,
                  }}
                  onClick={() => this.handleDelete(data.id)}
                >
                  Delete
                </button>
                <button
                  style={{
                    background: "#0c2074",
                    color: "white",
                    height: 35,
                    width: 100,
                    alignItems: "center",
                    borderRadius: 8,
                    marginRight: 20,
                  }}
                  onClick={() => this.openReseduleDialog()}
                >
                  Reschedule
                </button>
              </div>
            </Typography>
          )}
          <Dialog
            style={{ minHeight: 600 }}
            open={open}
            onClose={this.handleClose}
            maxWidth="md"
          >
            <DialogTitle>{`Reschedule Appointment`}</DialogTitle>
            <DialogContent>
              <React.Fragment>
                <div
                  style={{ marginTop: "1rem", minHeight: 400 }}
                  className="flex flex-col space-y-5 max-w-md mx-auto min-w-500 "
                >
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="Select Date"
                      value={selectedDate}
                      onChange={this.handleDateChange}
                      shouldDisableDate={this.disabledDate}
                      disablePast={true}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </LocalizationProvider>

                  <div>
                    <Select
                      placeholder="Available Time Slots"
                      options={timeSlotList}
                      onChange={(values) => this.handleTimeslots(values)}
                    />
                  </div>
                </div>
              </React.Fragment>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.handleCancelClose}>Cancel</Button>
              <Button onClick={this.handleReschedule}>Reschedule</Button>
            </DialogActions>
          </Dialog>
        </AccordionDetails>
      </Accordion>
    );
  }
}

export default withRouter(AppointmentAccordian);

