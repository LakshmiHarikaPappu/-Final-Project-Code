import React from "react";
import { withRouter } from "react-router";
import axios from "axios";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

class LocationAccordian extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      openCancelDailog: false,
      expanded: false,
    };
  }

  handleCancel = (e) => {
    e.stopPropagation();
    this.setState({ openCancelDailog: true });
  };

  handleCancelClose = (e) => {
    e.stopPropagation();
    this.setState({ openCancelDailog: false });
  };

  handleDelete = (id) => {
    let reqUrl = `http://localhost:8080/booking/location/delete/${id}`;
    axios.delete(reqUrl).then((res) => {
      this.props.updateLocationData();
    });
  };

  handleChange = (panel) => (event, isExpanded) => {
    // setExpanded(isExpanded ? panel : false);

    this.setState({
      expanded: isExpanded ? panel : false,
    });
  };

  handleStatus = (projectStatus) => {
    let reqUrl =
      "http://localhost:8080/projectManagementApplication/updateStatus";
    const json = {
      projectId: this.props.projectData.projectId,
      projectStatus: projectStatus,
    };
    axios.put(reqUrl, json).then((res) => {
      console.log("Status updated successfully");
      this.props.refreshData();
    });
    //call api & disbale the status field
  };

  render() {
    // const {userId,userRole,projectData,index} = this.props;
    const { expanded } = this.state;
    const { data } = this.props;
    const weekdaystarttime =
      data.weekdayStartTime < 12
        ? data.weekdayStartTime + " - AM"
        : data.weekdayStartTime === 12
        ? data.weekdayStartTime + " - PM"
        : data.weekdayStartTime - 12 + " - PM";
    const weekdayendtime =
      data.weekdayEndTime < 12
        ? data.weekdayEndTime + " - AM"
        : data.weekdayEndTime === 12
        ? data.weekdayEndTime + " - PM"
        : data.weekdayEndTime - 12 + " - PM";
    const weekendstarttime =
      data.weekendStartTime < 12
        ? data.weekendStartTime + " - AM"
        : data.weekendStartTime === 12
        ? data.weekendStartTime + " - PM"
        : data.weekendStartTime - 12 + " - PM";
    const weekendendtime =
      data.weekendEndTime < 12
        ? data.weekendEndTime + " - AM"
        : data.weekendEndTime === 12
        ? data.weekendEndTime + " - PM"
        : data.weekendEndTime - 12 + " - PM";
    return (
      <Accordion style={{ width: "50%" }}>
        <AccordionSummary
          style={{ alignItems: "center" }}
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1bh-content"
          id="panel1bh-header"
        >
          <Typography
            style={{ fontSize: "17px", fontWeight: "600" }}
            sx={{ width: "50%", flexShrink: 0 }}
          >
            Location ID : {data.id}
          </Typography>
          {/* <Typography sx={{ color: 'text.secondary' }}>{projectData.projectStatus}</Typography> */}
        </AccordionSummary>
        <AccordionDetails>
          <Typography
            style={{
              fontSize: "17px",
              fontWeight: "600",
              marginBottom: "12px",
            }}
          >
            Location Name : {data.name}
          </Typography>
          <Typography
            style={{
              display: "flex",
              justifyContent: "space-evenly",
              fontSize: "17px",
              marginBottom: "12px",
            }}
          >
            <div>Week Day start time : {weekdaystarttime}</div>
            <div>Week Day end time : {weekdayendtime}</div>
          </Typography>

          <Typography
            style={{
              display: "flex",
              justifyContent: "space-evenly",
              fontSize: "17px",
              marginBottom: "12px",
            }}
          >
            <div>Weekend start time : {weekendstarttime}</div>
            <div>Weekend end time : {weekendendtime}</div>
          </Typography>

          <Typography style={{ display: "flex" }}>
            <div style={{ display: "flex", flexGrow: "1" }}>
              <button
                style={{
                  background: "#0c2074",
                  color: "white",
                  height: 35,
                  width: 80,
                  alignItems: "center",
                  borderRadius: 8,
                  marginRight: 20,
                }}
                onClick={() => this.handleDelete(data.id)}
              >
                Delete
              </button>
            </div>
          </Typography>
        </AccordionDetails>
      </Accordion>
    );
  }
}

export default withRouter(LocationAccordian);
