import React from "react";
import { withRouter } from "react-router";
import axios from "axios";
import TextField from "@mui/material/TextField";
import NativeSelect from "@mui/material/NativeSelect";
import Button from "@mui/material/Button";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs, { Dayjs } from "dayjs";
import moment from "moment";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContentText from "@mui/material/DialogContentText";
import { Alert } from "@mui/material";
import Select from "react-dropdown-select";

const baseUrl = "http://localhost:8080/booking/location/all";
const bookingurl = "http://localhost:8080/booking/user/book";
const availableTimeSlot = "http://localhost:8080/booking/appointment/timeslot";
class BookingAppointment extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      applicationList: [],
      shouldAlertDisplay: false,
      locationName: "",
      serviceCategory: "",
      weekDayStartTime: dayjs("2020-01-01 08:00"),
      weekDayEndTime: dayjs("2020-01-01 18:00"),
      weekendStartTime: dayjs("2020-01-01 08:00"),
      weekendEndTime: dayjs("2020-01-01 18:00"),
      selectedLocation: "",
      selectedService: "",
      selectedApptype: "",
      selectedAppPurpose: "",
      selectedTimeSlot: "",
      displayTimeslot: false,
      locationList: [],
      serviceList: [],
      appTypeList: [
        { label: "Virtual Appointment", value: "Virtual Appointment" },
        { label: "Phonecall Appointment", value: "Phonecall Appointment" },
        { label: "Inperson Appointment", value: "Inperson Appointment" },
      ],
      appPurposeList: [
        {
          label: "Get help with my existing account",
          value: "Get help with my existing account",
        },
        {
          label: "Opening a checking, savings or credit card",
          value: "Opening a checking, savings or credit card",
        },
        {
          label: "Learn more about other products or services",
          value: "Learn more about other products or services",
        },
        { label: "Others", value: "Others" },
      ],
      timeSlotList: [],
      selectedDate: new Date("2022-12-05T21:11:54"),
      // selectedDate:new Date,
      open: false,
      name: "",
      email: "",
      phoneNumber: "",
      address: "",
      locationDetails: [],

      locationId: "",
      serviceId: "",
      appointmentType: "",
      userId: localStorage.getItem("userId"),
      purpose: "",
      bookingDate: "2022-12-05",
      bookingTime: "",
    };
  }

  componentDidMount() {
    axios.get(baseUrl).then((res) => {
      const locationList = res.data.locationDetails;
      const list = [];
      locationList.forEach((loc) => {
        let obj = {
          label: loc.location.name,
          value: loc.location.name,
        };
        list.push(obj);
      });
      this.setState({
        locationList: list,
        locationDetails: locationList,
      });
    });
  }

  handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userRole");
    const {
      history: { push },
    } = this.props;
    push("/");
  };

  handleDateChange = (date) => {
    const { locationId, appointmentType } = this.state;
    const timeList = [];

    const json = {
      locationId: locationId,
      appointmentType: appointmentType,
      bookingDate: date.target.value,
    };
    axios.post(availableTimeSlot, json).then((res) => {
      // let list=[9,10,11,12,13,15,18];
      let timeslotlist = res.data.availableSlot;
      timeslotlist.forEach((a) => {
        let obj = {};
        obj["label"] =
          a < 12 ? a + " - AM" : a === 12 ? a + " - PM" : a - 12 + " - PM";
        obj["value"] = a;
        timeList.push(obj);
      });
    });
    this.setState({
      selectedDate: date,
      bookingDate: date.target.value,
      displayTimeslot: true,
      timeSlotList: timeList,
    });
  };
  handleWeekendStartTime = (newTime) => {
    this.setState({
      weekendStartTime: newTime,
    });
  };

  handleWeekendEndTime = (newTime) => {
    this.setState({
      weekendEndTime: newTime,
    });
  };

  handleWeekDayStartTime = (newTime) => {
    this.setState({
      weekDayStartTime: newTime,
    });
  };

  handleSelectTime = (newTime) => {
    this.setState({
      selectedTime: newTime,
    });
  };

  handleBookingAppointment = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/bookingAppointment");
  };

  handleViewAppointments = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/viewAppointments");
  };

  handleHome = () => {
    const { userId } = this.state;
    const {
      history: { push },
    } = this.props;
    push("/userhome");
  };

  handleLogout = () => {
    const { userId } = this.state;
    localStorage.removeItem("userId");
    const {
      history: { push },
    } = this.props;
    push("/");
  };

  handleLocationList = (data) => {
    const { locationDetails } = this.state;
    const list = [];
    let locationId = "";
    locationDetails.forEach((a) => {
      if (a.location.name === data[0]["value"]) {
        locationId = a.location.id;
      }
    });

    this.setState({
      selectedLocation: data,
      locationId: locationId,
      shouldAlertDisplay: false,
    });
  };

  handleAppTypeList = (data) => {
    const timeList = [];
    const { locationId } = this.state;

    const json = {
      locationId: locationId,
      appointmentType: data[0]["value"],
      bookingDate: "2022-12-05",
    };
    axios.post(availableTimeSlot, json).then((res) => {
      let timeslotlist = res.data.availableSlot;
      timeslotlist.forEach((a) => {
        let obj = {};
        obj["label"] =
          a < 12 ? a + " - AM" : a === 12 ? a + " - PM" : a - 12 + " - PM";
        obj["value"] = a;
        timeList.push(obj);
      });
      this.setState({
        displayTimeslot: true,
        timeSlotList: timeList,
      });
    });
    this.setState({
      selectedApptype: data,
      appointmentType: data[0]["value"],
      shouldAlertDisplay: false,
    });
  };

  handleAppPurposeList = (data) => {
    this.setState({
      selectedAppPurpose: data,
      purpose: data[0]["value"],
      shouldAlertDisplay: false,
    });
  };

  handleTimeslots = (data) => {
    let bookingTime = data[0].value;
    this.setState({
      selectedTimeSlot: data,
      shouldAlertDisplay: false,
      bookingTime: bookingTime,
    });
  };

  handleClose = (data) => {
    this.setState({
      open: false,
    });
  };

  notificationHandleClose = (data) => {
    this.setState({
      notificationOpen: false,
    });
    const {
      history: { push },
    } = this.props;
    push("/userhome");
  };

  handleSubmit = (data) => {
    const {
      name,
      address,
      email,
      phoneNumber,
      locationId,
      serviceId,
      userId,
      appointmentType,
      purpose,
      bookingDate,
      bookingTime,
    } = this.state;
    const reqJson = {
      locationId: locationId,
      userId: userId,
      purpose: purpose,
      bookingUserName: name,
      bookingPhoneNumber: phoneNumber,
      bookingEmail: email,
      bookingDate: bookingDate,
      startTime: bookingTime,
      appointmentType: appointmentType,
      bookingAddress: address,
    };

    if (name === "" || email === "" || phoneNumber === "") {
      this.setState({
        shouldAlertDisplay: true,
      });
      return;
    }

    axios.post(bookingurl, reqJson).then((res) => {
      console.log(res);
    });

    this.setState({
      open: false,
      notificationOpen: true,
    });
  };

  handleNext = (data) => {
    const {
      locationId,
      serviceId,
      selectedApptype,
      purpose,
      selectedTimeSlot,
    } = this.state;
    if (
      locationId === "" ||
      purpose === "" ||
      selectedApptype === "" ||
      selectedTimeSlot === ""
    ) {
      this.setState({
        shouldAlertDisplay: true,
      });
      return;
    }
    this.setState({
      open: true,
    });
  };

  handleNameChange = (e) => {
    this.setState({ name: e.target.value, shouldAlertDisplay: false });
  };

  handleAddressChange = (e) => {
    this.setState({ address: e.target.value, shouldAlertDisplay: false });
  };

  handleEmailChange = (e) => {
    this.setState({ email: e.target.value, shouldAlertDisplay: false });
  };

  handlePhoneNumberChange = (e) => {
    this.setState({ phoneNumber: e.target.value, shouldAlertDisplay: false });
  };

  disabledDate = (current) => {
    const disabledDates = [];
    return (
      current < Date.now() ||
      disabledDates.find(
        (date) => date === moment(current).format("YYYY-MM-DD")
      )
    );
  };

  render() {
    const {
      notificationOpen,
      open,
      displayTimeslot,
      timeSlotList,
      appPurposeList,
      appTypeList,
      selectedApptype,
      selectedDate,
      selectedTime,
      selectedService,
      locationList,
      locationName,
      weekendStartTime,
      weekendEndTime,
      weekDayStartTime,
      weekDayEndTime,
      serviceList,
      shouldAlertDisplay,
    } = this.state;
    return (
      <div
        className=" flex flex-col"
        style={{ backgroundColor: "aliceBlueBlue", minHeight: "100vh" }}
      >
        <div
          style={{
            backgroundColor: "#0c2074",
            display: "flex",
            padding: "12px",
            color: "white",
          }}
        >
          <div style={{ display: "flex", flexGrow: "1" }}>
            <div
              style={{
                fontSize: "24px",
                fontWeight: "600",
                width: "100%",
                display: "flex",
                padding: "20px",
                alignItems: "center",
                color: "white",
              }}
            >
              BANK APPOINTMENT BOOKING
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 50,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleHome}
            >
              Home
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 50,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleBookingAppointment}
            >
              Book Appointment
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                marginRight: 150,
                fontSize: 18,
              }}
              className="underline cursor-pointer"
              onClick={this.handleViewAppointments}
            >
              View Appointments
            </div>
            <button
              style={{
                background: "white",
                color: "#0c2074",
                height: 35,
                width: 80,
                alignItems: "center",
                borderRadius: 8,
                marginRight: 20,
              }}
              onClick={this.handleLogout}
            >
              Logout
            </button>
          </div>
        </div>

        <div
          className="flex flex-col space-y-5 max-w-md mx-auto my-16 "
          style={{
            minWidth: "500px",
            backgroundColor: "",
            padding: "30px",
            borderRadius: 10,
          }}
        >
          <h2
            style={{
              color: "darkblue",
              display: "flex",
              justifyContent: "center",
              fontSize: 24,
            }}
            className=" font-semibold uppercase"
          >
            Appointment Details
          </h2>

          <Select
            placeholder="Select Location"
            options={locationList}
            onChange={(values) => this.handleLocationList(values)}
          />
          <Select
            placeholder="Appointment Type"
            options={appTypeList}
            onChange={(values) => this.handleAppTypeList(values)}
          />
          <Select
            placeholder="Purpose of the appointment"
            options={appPurposeList}
            onChange={(values) => this.handleAppPurposeList(values)}
          />

          <div style={{ width: 200 }}>
            <TextField
              id="date"
              label="Date"
              type="date"
              defaultValue="2022-12-05"
              onChange={this.handleDateChange}
              shouldDisableDate={this.disabledDate}
              sx={{ width: 220 }}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </div>

          {displayTimeslot && (
            <div style={{ width: 200 }}>
              <Select
                placeholder="Available Time Slots"
                options={timeSlotList}
                onChange={(values) => this.handleTimeslots(values)}
              />
            </div>
          )}

          <div className="flex items-center justify-between">
            <button
              style={{
                background: "#0c2074",
                color: "white",
                height: 35,
                width: 80,
                alignItems: "center",
                borderRadius: 8,
                marginRight: 20,
              }}
              onClick={this.handleNext}
            >
              Next
            </button>
          </div>
          {shouldAlertDisplay && (
            <Alert severity="error">Field cannot be empty</Alert>
          )}
          <Dialog open={open} onClose={this.handleClose} maxWidth="md">
            <DialogTitle>{`Contact Details`}</DialogTitle>
            <DialogContent>
              <React.Fragment>
                <div
                  style={{ marginTop: "1rem" }}
                  className="flex flex-col space-y-5 max-w-md mx-auto min-w-500"
                >
                  <TextField
                    required
                    id="outlined-username"
                    value={this.state.name}
                    label="Name"
                    autoComplete="off"
                    onChange={(e) => this.handleNameChange(e)}
                  />
                  <TextField
                    required
                    id="outlined-email"
                    value={this.state.email}
                    label="Email ID"
                    onChange={(e) => this.handleEmailChange(e)}
                  />
                  <TextField
                    required
                    id="outlined-phone"
                    value={this.state.phoneNumber}
                    label="Phone Number"
                    onChange={(e) => this.handlePhoneNumberChange(e)}
                  />
                  <TextField
                    id="outlined-phone"
                    label="Address"
                    value={this.state.address}
                    onChange={(e) => this.handleAddressChange(e)}
                  />{" "}
                </div>
                {shouldAlertDisplay && (
                  <Alert severity="error">
                    Please fill out mandatory fields
                  </Alert>
                )}
              </React.Fragment>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.handleClose}>Cancel</Button>
              <Button onClick={this.handleSubmit}>Submit</Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={notificationOpen}
            onClose={this.notificationHandleClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                Your Appointment has been scheduled successfully.
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.notificationHandleClose}>Ok</Button>
            </DialogActions>
          </Dialog>
        </div>
      </div>
    );
  }
}

export default withRouter(BookingAppointment);
