import ".././App.css";
import ".././index.css";
import { BrowserRouter, Route } from "react-router-dom";
import Login from "../components/BookAppLogin";
import Home from "../components/BookAppHome";
import SignUp from "../components/BookAppSignup";
import AddNewLocation from "../components/BookAppAddnewLoc";
import UserHome from "../components/BookAppUserHome";
import BookApp from "../components/BookApp";
import ViewApp from "../components/BookAppViewApp";
import ViewLoc from "../components/BookAppViewLoc";

import { withRouter } from "react-router";
const url = "http://localhost:8080/booking/user/login";
function RouterComp() {
    return (
   
    <BrowserRouter>
        <div className="flex flex-col min-h-screen" >
          <Route path="/" component={Login} exact></Route>
          <Route path="/signup" component={SignUp}></Route>
          <Route path="/home" component={Home}></Route>
          <Route path="/addLocation" component={AddNewLocation}></Route>
          <Route path="/viewLocation" component={ViewLoc}></Route>
          
  
          <Route path="/userhome" component={UserHome}></Route>
          <Route path="/bookingAppointment" component={BookApp}></Route>
          <Route path="/viewAppointments" component={ViewApp}></Route>
  
          
        </div>
      </BrowserRouter> 
    );
  }

export default RouterComp;
