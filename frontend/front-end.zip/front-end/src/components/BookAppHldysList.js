const HolidaysList = [
    "2022-11-10",
    "2022-11-16",
    "2022-11-24",
    "2022-12-25"
]
export default HolidaysList;