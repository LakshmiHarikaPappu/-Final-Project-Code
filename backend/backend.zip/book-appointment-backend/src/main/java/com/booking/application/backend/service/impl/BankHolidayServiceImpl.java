package com.booking.application.backend.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.booking.application.backend.domain.BankHoliday;
import com.booking.application.backend.repository.BankHolidayRepository;
import com.booking.application.backend.service.BankHolidayService;

@org.springframework.stereotype.Service
public class BankHolidayServiceImpl implements BankHolidayService {
	
	@Autowired
	BankHolidayRepository holidayRepository;

	@Override
	public Map<String, Object> getAllHolidays() {
		Map<String, Object> resultMap = new HashMap<>();
		List<BankHoliday> holidays = (List<BankHoliday>) holidayRepository.findAll();
		resultMap.put("holidays", holidays);
		return resultMap;
	}

	//list of holidays
	@Override
	public Map<String, Object> saveHolidays(List<BankHoliday> holidays) {
		Map<String, Object> resultMap = new HashMap<>();
		List<BankHoliday> newHolidays = new ArrayList<>();
		List<Long> deleteHolidays = new ArrayList<>();
		List<BankHoliday> existingHolidays = (List<BankHoliday>) holidayRepository.findAll();
		
		List<Long> updatedHolidayIdList = holidays.stream()
				.filter(service -> service.getId() != null && service.getId() != 0l)
				.map(BankHoliday::getId).collect(Collectors.toList());
		
		holidays.forEach(holiday -> {
			if(holiday.getId() == null || holiday.getId() == 0l) {
				newHolidays.add(holiday);
			}
		});
		
		existingHolidays.forEach(holiday -> {
			if(!updatedHolidayIdList.contains(holiday.getId())) {
				deleteHolidays.add(holiday.getId());
			}
		});
		
		if(!CollectionUtils.isEmpty(newHolidays)) {
			holidayRepository.saveAll(newHolidays);
		}
		if(!CollectionUtils.isEmpty(deleteHolidays)) {
			holidayRepository.deleteAllById(deleteHolidays);
		}
		
		existingHolidays = (List<BankHoliday>) holidayRepository.findAll();
		resultMap.put("holidays", existingHolidays);
		return resultMap;
	}
	
}
