package com.booking.application.backend.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.booking.application.backend.domain.BankHoliday;

@Repository
public interface BankHolidayRepository extends CrudRepository<BankHoliday, Long> {
	
}
