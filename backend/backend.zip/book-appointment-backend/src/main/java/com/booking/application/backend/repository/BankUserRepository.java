package com.booking.application.backend.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.booking.application.backend.domain.BankUser;

@Repository
public interface BankUserRepository extends CrudRepository<BankUser, Long> {
	
	Optional<BankUser> findByUserNameAndPassword(String username,String password);
	
	Optional<BankUser> findByUserName(String username);

}
