package com.booking.application.backend.entity;


import java.util.List;

import com.booking.application.backend.domain.BankLocation;

import lombok.Data;

@Data
public class BankLocationDetails {

	private BankLocation location;
	public BankLocation getLocation() {
		return location;
	}
	public void setLocation(BankLocation location) {
		this.location = location;
	}
	
	
}
