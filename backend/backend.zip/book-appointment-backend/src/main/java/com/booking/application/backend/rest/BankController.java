package com.booking.application.backend.rest;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.booking.application.backend.domain.BankHoliday;
import com.booking.application.backend.domain.BankUser;
import com.booking.application.backend.entity.BankLocationDetails;
import com.booking.application.backend.entity.BankTimeslotDetails;
import com.booking.application.backend.service.BankHolidayService;
import com.booking.application.backend.service.BankLocationService;
import com.booking.application.backend.service.BankTimeSlotService;
import com.booking.application.backend.service.BankUserService;

@CrossOrigin(origins = "http://localhost:3000")
@Controller
@RequestMapping("/booking")
public class BankController {
	
	private BankHolidayService holidayService;
	private BankLocationService locationService;
	private BankTimeSlotService timeSlotService;
	private BankUserService userService;
	
	@Autowired
	public BankController(BankHolidayService holidayService,
			BankLocationService locationService,
			BankTimeSlotService timeSlotService,
			BankUserService userService) {
		this.holidayService = holidayService;
		this.locationService = locationService;
		this.timeSlotService = timeSlotService;
		this.userService = userService;
	}
	//holiday 
	@PostMapping(value = "/holiday/save")
	ResponseEntity<Map> saveHolidays(@RequestBody List<BankHoliday> holidays){
		return ResponseEntity.status(HttpStatus.OK).body(holidayService.saveHolidays(holidays));
	}
	
	@GetMapping(value = "/holiday/all")
	ResponseEntity<Map> getAllHolidays(){
		return ResponseEntity.status(HttpStatus.OK).body(holidayService.getAllHolidays());
	}
	//location	
	@PostMapping(value = "/location/save")
	ResponseEntity<Map> saveLocation(@RequestBody BankLocationDetails locationDetail){
		return ResponseEntity.status(HttpStatus.OK).body(locationService.saveLocation(locationDetail));
	}
	
	@GetMapping(value = "/location/all")
	ResponseEntity<Map> getAllLocations(){
		return ResponseEntity.status(HttpStatus.OK).body(locationService.getAllLocations());
	}
	
	@DeleteMapping(value = "/location/delete/{id}")
	ResponseEntity<Map> deleteLocation(@PathVariable(name = "id",required = true) Long id){
		return ResponseEntity.status(HttpStatus.OK).body(locationService.deleteLocation(id));
	}
	//timeslots
	@GetMapping(value = "/history/user/{id}")
	ResponseEntity<Map> getHistoryByUserId(@PathVariable(name = "id",required = true) Long id){
		return ResponseEntity.status(HttpStatus.OK).body(timeSlotService.getHistoryByUserId(id));
	}
	
	@GetMapping(value = "/history/location/{id}")
	ResponseEntity<Map> getHistoryByLocationId(@PathVariable(name = "id",required = true) Long id){
		return ResponseEntity.status(HttpStatus.OK).body(timeSlotService.getHistoryByLocationId(id));
	}
	
	@GetMapping(value = "/history/all")
	ResponseEntity<Map> getAllBooking(){
		return ResponseEntity.status(HttpStatus.OK).body(timeSlotService.getAllBooking());
	}
	
	@DeleteMapping(value = "/delete/appointment/{id}")
	ResponseEntity<Map> deleteAppointment(@PathVariable(name = "id",required = true) Long id){
		return ResponseEntity.status(HttpStatus.OK).body(timeSlotService.deleteAppointment(id));
	}
	
	@PostMapping(value = "/appointment/timeslot")
	ResponseEntity<Map> getAvailableTimeSlot(@RequestBody BankTimeslotDetails timeSlot){
		return ResponseEntity.status(HttpStatus.OK).body(timeSlotService.getAvailableTimeslot(timeSlot));
	}
	//user	
	@PostMapping(value = "/user/save")
	ResponseEntity<Map> saveUser(@RequestBody BankUser user){
		return ResponseEntity.status(HttpStatus.OK).body(userService.saveUser(user));
	}
	
	@PostMapping(value = "/user/login")
	ResponseEntity<Map> checkUser(@RequestBody BankUser user){
		return ResponseEntity.status(HttpStatus.OK).body(userService.checkUser(user));
	}
	
	@PostMapping(value = "/user/book")
	ResponseEntity<Map> bookSlot(@RequestBody BankTimeslotDetails timeSlot){
		return ResponseEntity.status(HttpStatus.OK).body(userService.bookSlot(timeSlot));
	}
	
	@PostMapping(value = "/user/updateBooking")
	ResponseEntity<Map> updateBooking(@RequestBody BankTimeslotDetails timeSlot){
		return ResponseEntity.status(HttpStatus.OK).body(userService.updateBooking(timeSlot));
	}
	
	
}
