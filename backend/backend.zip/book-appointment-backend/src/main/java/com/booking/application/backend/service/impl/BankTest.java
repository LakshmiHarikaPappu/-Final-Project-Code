package com.booking.application.backend.service.impl;

import java.sql.Date;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class BankTest {
	
	public static void main(String[] args) {
		Date date = Date.valueOf("2022-10-31");
		System.out.println(date);
		long time = date.getTime();
		long addTime = 9*60*60*1000;
		System.out.println(addTime+time);
		java.util.Date date3 = new java.util.Date(time);
		System.out.println("Added Date :" +  date3);
		java.util.Date date2 = new java.util.Date(addTime+time);
		System.out.println("Added Date :" +  date2);
	}
}
