package com.booking.application.backend.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.booking.application.backend.domain.BankLocation;

@Repository
public interface BankLocationRepository extends CrudRepository<BankLocation, Long> {
	
}
