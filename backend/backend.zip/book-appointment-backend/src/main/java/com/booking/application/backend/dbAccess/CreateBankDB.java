package com.booking.application.backend.dbAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CreateBankDB {
	
	public static void main(String[] args) {
		try(Connection conn = createNewDBconnection()){
			createSchemaAndTables(conn);
			System.out.println("Tables and schema created");
			conn.close();
		}catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	
	private static void createSchemaAndTables(Connection connection) {
		try {
			connection.prepareStatement("DROP SCHEMA if exists bookingapplication").execute();
			PreparedStatement statement = connection.prepareStatement("CREATE DATABASE bookingapplication"); 
			statement.execute();
			connection.setSchema("bookingapplication");
			String createUser = "CREATE TABLE bookingapplication.user ("+ 
					"					id MEDIUMINT NOT NULL AUTO_INCREMENT,"+ 
					"					first_name varchar(150)," +
					"					last_name varchar(150)," +
					"					user_name varchar(150)," +
					"					email varchar(150)," +
					"					phone_number varchar(150)," +
					"					password varchar(150)," +
					"					user_type varchar(150)," +
					"					Constraint PK Primary Key(id)"+ 
					"					)";
			String createLocation = "CREATE TABLE bookingapplication.location (" + 
					"					id MEDIUMINT NOT NULL AUTO_INCREMENT,"+
					"					name varchar(150)," +
					"					weekday_start_time MEDIUMINT," +
					"					weekday_end_time MEDIUMINT," +
					"					weekend_start_time MEDIUMINT," +
					"					weekend_end_time MEDIUMINT," +
					"					Constraint PK Primary Key(id)"+ 
					")";
		
			String createTimeSlot = "CREATE TABLE bookingapplication.time_slot (" +
					"					id MEDIUMINT NOT NULL AUTO_INCREMENT,"+
					"					location_id MEDIUMINT NOT NULL,"+
					"					user_id MEDIUMINT NOT NULL,"+
					"					purpose varchar(150)," +
					"					appointment_type varchar(150)," +
					"					booking_user_name varchar(150)," +
					"					booking_phone_number varchar(150)," +
					"					booking_email varchar(150)," +
					"					booking_address varchar(450)," +
					"					booking_date datetime," +
					"					start_time MEDIUMINT," +
					"					end_time MEDIUMINT," +
					"					Constraint PK Primary Key(id),"+ 
//					" 	 				Constraint location_time_fk FOREIGN KEY (location_id) REFERENCES location(id),"+
//					" 	 				Constraint service_time_fk FOREIGN KEY (service_id) REFERENCES service(id),"+
					" 	 				Constraint user_time_fk FOREIGN KEY (user_id) REFERENCES user(id)"+
					")";
			String createHolidays = "CREATE TABLE bookingapplication.holiday (" + 
					"					id MEDIUMINT NOT NULL AUTO_INCREMENT,"+
					"					date datetime," +
					"					Constraint PK Primary Key(id)"+
					")";
			
			connection.prepareStatement(createUser).execute();
			connection.prepareStatement(createLocation).execute();
			connection.prepareStatement(createTimeSlot).execute();
			connection.prepareStatement(createHolidays).execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String dbhost = "jdbc:mysql://localhost:3306";
	private static String username = "root";
	private static String password = "root";
	private static Connection conn;
	
	@SuppressWarnings("finally")
	public static Connection createNewDBconnection() {
		try  {	
			conn = DriverManager.getConnection(
					dbhost, username, password);	
		} catch (SQLException e) {
			System.out.println("Cannot create database connection");
			e.printStackTrace();
		} finally {
			return conn;	
		}		
	}
}
