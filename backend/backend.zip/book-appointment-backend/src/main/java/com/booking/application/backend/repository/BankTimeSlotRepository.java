package com.booking.application.backend.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.booking.application.backend.domain.BankTimeSlot;

@Repository
public interface BankTimeSlotRepository extends CrudRepository<BankTimeSlot, Long> {
	
	List<BankTimeSlot> findByLocationIdAndBookingDateOrderByStartTime(Long locationId,Date bookingDate);
	
	List<BankTimeSlot> findByLocationIdAndAppointmentTypeAndBookingDateOrderByStartTime(Long locationId, String appointmenType, Date bookingDate);
	
	List<BankTimeSlot> findByUserId(Long userId);
	
	List<BankTimeSlot> findByLocationId(Long locationId);
	
	void deleteAllByLocationId(Long locationId);
	
}
