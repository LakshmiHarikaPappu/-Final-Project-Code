package com.booking.application.backend.service;

import java.util.List;
import java.util.Map;

import com.booking.application.backend.domain.BankHoliday;

public interface BankHolidayService {

	Map<String,Object> getAllHolidays();

	Map<String,Object> saveHolidays(List<BankHoliday> holidays);

}
