package com.booking.application.backend.service.impl;

import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.booking.application.backend.domain.BankHoliday;
import com.booking.application.backend.domain.BankLocation;
import com.booking.application.backend.domain.BankTimeSlot;
import com.booking.application.backend.domain.BankUser;
import com.booking.application.backend.entity.BankTimeslotDetails;
import com.booking.application.backend.repository.BankHolidayRepository;
import com.booking.application.backend.repository.BankLocationRepository;
import com.booking.application.backend.repository.BankTimeSlotRepository;
import com.booking.application.backend.repository.BankUserRepository;
import com.booking.application.backend.service.BankUserService;

import biweekly.Biweekly;
import biweekly.ICalendar;
import biweekly.component.VEvent;
import biweekly.parameter.ParticipationLevel;
import biweekly.property.Attendee;
import biweekly.property.Method;
import biweekly.property.Organizer;
import biweekly.util.Duration;

@Service
public class BankUserServiceImpl implements BankUserService {

	@Autowired
	BankUserRepository userRepository;

	@Autowired
	BankTimeSlotRepository timeSlotRepository;

	@Autowired
	BankLocationRepository locationRepository;

	@Autowired
	BankHolidayRepository holidayRepository;
	
	@Override
	public Map saveUser(BankUser user) {
		Map<String, Object> resultMap = new HashMap<>();
		Optional<BankUser> userOpt = userRepository.findByUserName(user.getUserName());
		if(userOpt.isPresent()) {
			resultMap.put("error", "username already exists");
			return resultMap;
		}
		user = userRepository.save(user);
		resultMap.put("user", user);
		return resultMap;
	}

	@Override
	public Map<String, Object> checkUser(BankUser user) {
		Map<String, Object> resultMap = new HashMap<>();
		Optional<BankUser> userOpt = userRepository.findByUserNameAndPassword(user.getUserName(), user.getPassword());
		if(userOpt.isPresent())
			resultMap.put("user", userOpt.get());
		else
			resultMap.put("error", "Invalid username/password");
		return resultMap;
	}

	@Override
	public Map<String, Object> bookSlot(BankTimeslotDetails timeSlot){
		Map<String, Object> resultMap = new HashMap<>();
		
		Date date = Date.valueOf(timeSlot.getBookingDate());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int day = cal.get(Calendar.DAY_OF_WEEK);
		int startTime = timeSlot.getStartTime();
		Optional<BankLocation> locationOpt = locationRepository.findById(timeSlot.getLocationId());
		if(!locationOpt.isPresent()) {
			resultMap.put("error", "Location not found");
			return resultMap;
		}
		BankLocation location = locationOpt.get();
		int locationStartTime = location.getWeekendStartTime();
		int locationEndTime = location.getWeekendEndTime();
		
		BankTimeSlot time=new BankTimeSlot();
		time.setLocationId(timeSlot.getLocationId());
		time.setUserId(timeSlot.getUserId());
		time.setPurpose(timeSlot.getPurpose());
		time.setAppointmentType(timeSlot.getAppointmentType());
		time.setBookingUserName(timeSlot.getBookingUserName());
		time.setBookingPhoneNumber(timeSlot.getBookingPhoneNumber());
		time.setBookingEmail(timeSlot.getBookingEmail());
		time.setBookingAddress(timeSlot.getBookingAddress());
		time.setBookingDate(Date.valueOf(timeSlot.getBookingDate()));
		time.setStartTime(timeSlot.getStartTime());
		time.setEndTime(timeSlot.getEndTime());
		time = timeSlotRepository.save(time);
		resultMap.put("timeSlot", time);		
	
		sendMail(time,location);

		return resultMap;
	}
    //send email when appointment is booked
	public void sendMail(BankTimeSlot timeSlot,BankLocation location) {
		Properties prop = new Properties();
		prop.put("mail.smtp.auth", true);
		prop.put("mail.smtp.starttls.enable", true);
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.ssl.trust", "*");
		prop.put("mail.smtp.ssl.protocols", "TLSv1.2");
		
		//senders email and password .ex:bank email
		String username = "harikanitt@gmail.com";
		String password = "tdpegndukexyfsbo";
		
		SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMMM yyyy");  
		String strDate = formatter.format(timeSlot.getBookingDate());
		SimpleDateFormat formatter2 = new SimpleDateFormat("z");  
		String strZone = formatter2.format(timeSlot.getBookingDate());
		String amOrpm = timeSlot.getStartTime() < 12 ? "AM" : "PM";
		int time = timeSlot.getStartTime() > 12 ? timeSlot.getStartTime() - 12 : timeSlot.getStartTime();
		String bookingTime = strDate +", " + time + ":00 " + amOrpm + " "+ strZone;
		String address = StringUtils.hasText(timeSlot.getBookingAddress()) ? "" : timeSlot.getBookingAddress();
		String type = StringUtils.hasText(timeSlot.getAppointmentType()) ? "" : timeSlot.getAppointmentType();
		
		Session session = Session.getInstance(prop, new Authenticator() {
		    @Override
		    protected PasswordAuthentication getPasswordAuthentication() {
		        return new PasswordAuthentication(username, password);
		    }
		});
		
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(
			  Message.RecipientType.TO, InternetAddress.parse(timeSlot.getBookingEmail()));
			message.setSubject("Appointment confirmed");
	        //message in email when appointment is booked
			String msg = "Your appointment has been scheduled and confirmed!\n\n"
					+ "Hey "+ timeSlot.getBookingUserName()+",\n\n"
					+ "This email is to let you know that your appointment with Student bank has been confirmed. Please find the infomation below.\n\n"
					+  bookingTime + "\n"
					+ "Type: "+ timeSlot.getAppointmentType() +"\n"
							+ "Location: "+ location.getName() +"\n\n\n"
					
					+ "Provided by,\n"
					+ "Student Bank";
			
	
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			mimeBodyPart.setText(msg);
			
			final MimeBodyPart iCalPart = new MimeBodyPart();
			//calender invite
			iCalPart.setHeader("Content-Class", "urn:content-classes:calendarmessage");
			iCalPart.setHeader("Content-ID", "calendar_message");
			try {
				iCalPart.setDataHandler(new DataHandler(
				        new ByteArrayDataSource(generateICalData(username,timeSlot), "text/calendar;method=REQUEST;name=\"invite.ics\"")));
			} catch (IOException e) {
				e.printStackTrace();
			}
	
			Multipart multipart = new MimeMultipart("mixed");
			multipart.addBodyPart(mimeBodyPart);
			multipart.addBodyPart(iCalPart);
	
			message.setContent(multipart);

			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}		
	}
	
	public String generateICalData(String fromEmail,BankTimeSlot timeslot) {
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date formatedDate = java.sql.Date.valueOf(format.format(timeslot.getBookingDate()));
		long time = formatedDate.getTime()+timeslot.getStartTime()*60*60*1000;
		
		java.util.Date calDate = new java.util.Date(time);
		
	    ICalendar ical = new ICalendar();
	    ical.addProperty(new Method(Method.REQUEST));

        VEvent event = new VEvent();
        event.setSummary("Appointment confirmed");
        event.setDescription("You having been invited to this with Student bank");

        event.setDateStart(calDate);
        event.setDuration(new Duration.Builder()
                                  .hours(1)
                                  .build());

        event.setOrganizer(new Organizer("Organizer", fromEmail));

        Attendee a = new Attendee("Attendee", timeslot.getBookingEmail());
        a.setParticipationLevel(ParticipationLevel.REQUIRED);
        event.addAttendee(a);
        ical.addEvent(event);

	    return Biweekly.write(ical).go();
	}
	
	@Override
	public Map<String, Object> updateBooking(BankTimeslotDetails timeSlot) {
		Map<String, Object> resultMap = new HashMap<>();
		BankTimeSlot time=new BankTimeSlot();
		time.setId(timeSlot.getId());
		time.setLocationId(timeSlot.getLocationId());
		time.setUserId(timeSlot.getUserId());
		time.setPurpose(timeSlot.getPurpose());
		time.setAppointmentType(timeSlot.getAppointmentType());
		time.setBookingUserName(timeSlot.getBookingUserName());
		time.setBookingPhoneNumber(timeSlot.getBookingPhoneNumber());
		time.setBookingEmail(timeSlot.getBookingEmail());
		time.setBookingAddress(timeSlot.getBookingAddress());
		time.setBookingDate(Date.valueOf(timeSlot.getBookingDate()));
		time.setStartTime(timeSlot.getStartTime());
		time.setEndTime(timeSlot.getEndTime());
		time = timeSlotRepository.save(time);
		
		resultMap.put("timeSlot", time);
		Optional<BankLocation> locationOpt = locationRepository.findById(timeSlot.getLocationId());
		if(!locationOpt.isPresent()) {
			resultMap.put("error", "Location not found");
			return resultMap;
		}
		BankLocation location = locationOpt.get();
		sendRescheduleMail(time,location);
		return resultMap;
	}
	//send reschedule email
	public void sendRescheduleMail(BankTimeSlot timeSlot,BankLocation location) {
		Properties prop = new Properties();
		prop.put("mail.smtp.auth", true);
		prop.put("mail.smtp.starttls.enable", true);
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.ssl.trust", "*");
		prop.put("mail.smtp.ssl.protocols", "TLSv1.2");
		
		//sender's i.e bank's email and password
		String username = "harikanitt@gmail.com";
		String password = "tdpegndukexyfsbo";
		
		SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMMM yyyy");  
		String strDate = formatter.format(timeSlot.getBookingDate());
		SimpleDateFormat formatter2 = new SimpleDateFormat("z");  
		String strZone = formatter2.format(timeSlot.getBookingDate());
		String amOrpm = timeSlot.getStartTime() < 12 ? "AM" : "PM";
		int time = timeSlot.getStartTime() > 12 ? timeSlot.getStartTime() - 12 : timeSlot.getStartTime();
		String bookingTime = strDate +", " + time + ":00 " + amOrpm + " "+ strZone;
		String address = StringUtils.hasText(timeSlot.getBookingAddress()) ? "" : timeSlot.getBookingAddress();
		String type = StringUtils.hasText(timeSlot.getAppointmentType()) ? "" : timeSlot.getAppointmentType();
		
		Session session = Session.getInstance(prop, new Authenticator() {
		    @Override
		    protected PasswordAuthentication getPasswordAuthentication() {
		        return new PasswordAuthentication(username, password);
		    }
		});
		
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(
			  Message.RecipientType.TO, InternetAddress.parse(timeSlot.getBookingEmail()));
			message.setSubject("Appointment Rescheduled");
	        //message in email send when rescheduled
			String msg = "Your appointment has been rescheduled and confirmed!\n\n"
					+ "Hey "+ timeSlot.getBookingUserName()+",\n\n"
					+ "This email is to let you know that your appointment with Student bank has been rescheduled. Please find the infomation below.\n\n"
					+  bookingTime + "\n"
					+ "Type: "+ timeSlot.getAppointmentType() +"\n"
							+ "Location: "+ location.getName() +"\n\n\n"
					
					+ "Provided by,\n"
					+ "Student Bank";
			
	
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			mimeBodyPart.setText(msg);
			Multipart multipart = new MimeMultipart("mixed");
			multipart.addBodyPart(mimeBodyPart);
			message.setContent(multipart);
			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}		
	}
}
