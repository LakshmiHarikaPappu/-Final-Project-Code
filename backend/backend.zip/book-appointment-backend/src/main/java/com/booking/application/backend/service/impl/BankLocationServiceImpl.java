package com.booking.application.backend.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.booking.application.backend.domain.BankLocation;
import com.booking.application.backend.entity.BankLocationDetails;
import com.booking.application.backend.repository.BankLocationRepository;
import com.booking.application.backend.repository.BankTimeSlotRepository;
import com.booking.application.backend.service.BankLocationService;

@org.springframework.stereotype.Service
public class BankLocationServiceImpl implements BankLocationService {
	
	@Autowired
	BankLocationRepository locationRepository;	
	@Autowired
	BankTimeSlotRepository timeSlotRepository;
    //save location
	@Override
	public Map saveLocation(BankLocationDetails locationDetail) {
		Map<String, Object> resultMap = new HashMap<>();
		List<Long> deleteServiceIdList = new ArrayList<>();
		BankLocation location = locationDetail.getLocation();
		location = locationRepository.save(location);
		locationDetail.setLocation(location);
		Long locationId = location.getId();		
		resultMap.put("locationDetail", locationDetail);
		return resultMap;
	}
	
	@Override
	public Map<String, Object> getAllLocations(){
		Map<String, Object> resultMap = new HashMap<>();
		List<BankLocationDetails> locationDetails = new ArrayList<>();
		List<BankLocation> locations = (List<BankLocation>) locationRepository.findAll();
		locations.stream().forEach(location -> {
			BankLocationDetails locationDetail = new BankLocationDetails();
			locationDetail.setLocation(location);
			locationDetails.add(locationDetail);
		});
		resultMap.put("locationDetails", locationDetails);
		return resultMap;
	}

	@Override
	@Transactional
	public Map<String, Object> deleteLocation(Long id) {
		Map<String, Object> resultMap = new HashMap<>();
		Optional<BankLocation> locationOpt = locationRepository.findById(id);
		if(locationOpt.isPresent()) {
			timeSlotRepository.deleteAllByLocationId(id);
			locationRepository.delete(locationOpt.get());
		}
		return resultMap;
	}

}
