package com.booking.application.backend.service;

import java.util.Map;

import com.booking.application.backend.domain.BankTimeSlot;
import com.booking.application.backend.entity.BankTimeslotDetails;

public interface BankTimeSlotService {

	Map<String, Object> getHistoryByUserId(Long userId);

	Map<String, Object> getHistoryByLocationId(Long id);

	Map<String, Object> getAllBooking();

	Map<String, Object> deleteAppointment(Long id);

	Map<String, Object> getAvailableTimeslot(BankTimeslotDetails timeSlot);

}
