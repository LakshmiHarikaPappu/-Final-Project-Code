package com.booking.application.backend.service.impl;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.booking.application.backend.domain.BankLocation;
import com.booking.application.backend.domain.BankTimeSlot;
import com.booking.application.backend.entity.BankTimeslotDetails;
import com.booking.application.backend.repository.BankLocationRepository;
import com.booking.application.backend.repository.BankTimeSlotRepository;
import com.booking.application.backend.service.BankTimeSlotService;

@Service
public class BankTimeSlotServiceImpl implements BankTimeSlotService {
	
	@Autowired
	BankTimeSlotRepository timeSlotRepository;	
	@Autowired
	BankLocationRepository locationRepository;	
	@Override
	public Map<String, Object> getHistoryByUserId(Long id) {
		Map<String, Object> resultMap = new HashMap<>();
		List<BankTimeSlot> timeslots = timeSlotRepository.findByUserId(id);
		Map<Long,BankLocation> locationMap = getLocationMap(timeslots);
		List<BankTimeslotDetails> timeslotDetails = getTimeslotDetails(timeslots, locationMap);
		resultMap.put("history",timeslotDetails);
		return resultMap;
	}
    //time slot details
	private List<BankTimeslotDetails> getTimeslotDetails(List<BankTimeSlot> timeslots, Map<Long, BankLocation> locationMap) {
		List<BankTimeslotDetails> timeslotDetails = new ArrayList<>();
		timeslots.forEach(timeslot -> {
			BankLocation location = locationMap.get(timeslot.getLocationId());
			BankTimeslotDetails timeslotDetail = new BankTimeslotDetails();
			timeslotDetail.setAppointmentType(timeslot.getAppointmentType());
			timeslotDetail.setBookingAddress(timeslot.getBookingAddress());
			timeslotDetail.setBookingDate(timeslot.getBookingDate().toString());
			timeslotDetail.setBookingEmail(timeslot.getBookingEmail());
			timeslotDetail.setBookingPhoneNumber(timeslot.getBookingPhoneNumber());
			timeslotDetail.setBookingUserName(timeslot.getBookingUserName());
			timeslotDetail.setEndTime(timeslot.getEndTime());
			timeslotDetail.setId(timeslot.getId());
			timeslotDetail.setLocationId(timeslot.getLocationId());
			timeslotDetail.setLocationName(location.getName());
			timeslotDetail.setPurpose(timeslot.getPurpose());
			timeslotDetail.setStartTime(timeslot.getStartTime());
			timeslotDetail.setUserId(timeslot.getUserId());
			timeslotDetails.add(timeslotDetail);
		});
		return timeslotDetails;
	}

	private Map<Long,BankLocation> getLocationMap(List<BankTimeSlot> timeslots) {
		List<Long> locationIds = timeslots.stream().map(BankTimeSlot::getLocationId).collect(Collectors.toList());
		List<BankLocation> locations = (List<BankLocation>) locationRepository.findAllById(locationIds);
		Map<Long,BankLocation> locationMap = locations.stream().collect(Collectors.toMap(BankLocation::getId,location -> location));
		return locationMap;
	}

	@Override
	public Map<String, Object> getHistoryByLocationId(Long id) {
		Map<String, Object> resultMap = new HashMap<>();
		List<BankTimeSlot> timeslots = timeSlotRepository.findByLocationId(id);
		Map<Long,BankLocation> locationMap = getLocationMap(timeslots);
		List<BankTimeslotDetails> timeslotDetails = getTimeslotDetails(timeslots, locationMap);
		resultMap.put("history",timeslotDetails);
		return resultMap;
	}

	@Override
	public Map<String, Object> getAllBooking() {
		Map<String, Object> resultMap = new HashMap<>();
		List<BankTimeSlot> timeslots = (List<BankTimeSlot>) timeSlotRepository.findAll();
		Map<Long,BankLocation> locationMap = getLocationMap(timeslots);
		List<BankTimeslotDetails> timeslotDetails = getTimeslotDetails(timeslots, locationMap);
		resultMap.put("history",timeslotDetails);
		return resultMap;
	}
	
	@Override
	@Transactional
	public Map<String, Object> deleteAppointment(Long id){
		Map<String, Object> resultMap = new HashMap<>();
		BankTimeSlot timeSlot=timeSlotRepository.findById(id).get();
		if(timeSlotRepository.findById(id).isPresent()) {
			timeSlotRepository.deleteById(id);
			Optional<BankLocation> locationOpt = locationRepository.findById(timeSlot.getLocationId());
			if(!locationOpt.isPresent()) {
				resultMap.put("error", "Location not found");
				return resultMap;
			}
			BankLocation location = locationOpt.get();
			sendDeleteMail(timeSlot,location);
			resultMap.put("sucess","timeslot removed");
		}else {
			resultMap.put("error","timeslot not found");
		}
		return resultMap;
	}
	//send mail when clicked delete from view appointments
	public void sendDeleteMail(BankTimeSlot timeSlot,BankLocation location) {
		Properties prop = new Properties();
		prop.put("mail.smtp.auth", true);
		prop.put("mail.smtp.starttls.enable", true);
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.ssl.trust", "*");
		prop.put("mail.smtp.ssl.protocols", "TLSv1.2");
		//sender i.e bank email and password
		String username = "harikanitt@gmail.com";
		String password = "tdpegndukexyfsbo";
		
		SimpleDateFormat formatter = new SimpleDateFormat("E, dd MMMM yyyy");  
		String strDate = formatter.format(timeSlot.getBookingDate());
		SimpleDateFormat formatter2 = new SimpleDateFormat("z");  
		String strZone = formatter2.format(timeSlot.getBookingDate());
		String amOrpm = timeSlot.getStartTime() < 12 ? "AM" : "PM";
		int time = timeSlot.getStartTime() > 12 ? timeSlot.getStartTime() - 12 : timeSlot.getStartTime();
		String bookingTime = strDate +", " + time + ":00 " + amOrpm + " "+ strZone;
		String address = StringUtils.hasText(timeSlot.getBookingAddress()) ? "" : timeSlot.getBookingAddress();
		String type = StringUtils.hasText(timeSlot.getAppointmentType()) ? "" : timeSlot.getAppointmentType();
		
		Session session = Session.getInstance(prop, new Authenticator() {
		    @Override
		    protected PasswordAuthentication getPasswordAuthentication() {
		        return new PasswordAuthentication(username, password);
		    }
		});
		
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(
			  Message.RecipientType.TO, InternetAddress.parse(timeSlot.getBookingEmail()));
			message.setSubject("Appointment Cancelled");
	        //message in cancel email
			String msg = "Your appointment has been cancelled!\n\n"
					+ "Hey "+ timeSlot.getBookingUserName()+",\n\n"
					+ "This email is to let you know that your appointment with Student bank has been cancelled. Please find the infomation below.\n\n"
					+  bookingTime + "\n"
					+ "Type: "+ timeSlot.getAppointmentType() +"\n"
							+ "Location: "+ location.getName() +"\n\n\n"
					
					+ "Provided by,\n"
					+ "Student Bank";
			
	
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			mimeBodyPart.setText(msg);
			Multipart multipart = new MimeMultipart("mixed");
			multipart.addBodyPart(mimeBodyPart);
			message.setContent(multipart);
			Transport.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}		
	}

	
	@Override
	public Map<String, Object> getAvailableTimeslot(BankTimeslotDetails timeSlot) {
		Map<String, Object> resultMap = new HashMap<>();
		List<BankTimeSlot> timeSlots = timeSlotRepository.findByLocationIdAndAppointmentTypeAndBookingDateOrderByStartTime(timeSlot.getLocationId(),
				timeSlot.getAppointmentType(),Date.valueOf(timeSlot.getBookingDate()));
		List<Integer> bookedSlots = timeSlots.stream().map(BankTimeSlot::getStartTime).collect(Collectors.toList());
		List<Integer> timeSlotList = new ArrayList<>();
		List<Integer> availableTimeSlots = new ArrayList<>();
		Date date = Date.valueOf(timeSlot.getBookingDate());
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int day = cal.get(Calendar.DAY_OF_WEEK);
		Optional<BankLocation> locationOpt = locationRepository.findById(timeSlot.getLocationId());
		if(!locationOpt.isPresent()) {
			resultMap.put("error", "Location not found");
			return resultMap;
		}
		BankLocation location = locationOpt.get();
		int locationStartTime = location.getWeekendStartTime();
		int locationEndTime = location.getWeekendEndTime();
		if(day != 1 && day !=7) {
			locationStartTime = location.getWeekdayStartTime();
			locationEndTime = location.getWeekdayEndTime();
		}
		for(int i = locationStartTime; i < locationEndTime; i++) {
			timeSlotList.add(i);
		}
		timeSlotList.forEach(timeslot ->{
			if(!bookedSlots.contains(timeslot))
				availableTimeSlots.add(timeslot);
		});
		resultMap.put("availableSlot", availableTimeSlots);
		return resultMap;
	}

}
