package com.booking.application.backend.service;

import java.util.Map;

import com.booking.application.backend.domain.BankUser;
import com.booking.application.backend.entity.BankLocationDetails;

public interface BankLocationService {

	Map<String, Object> saveLocation(BankLocationDetails locationDetail);

	Map<String, Object> getAllLocations();

	Map<String, Object> deleteLocation(Long id);

}
