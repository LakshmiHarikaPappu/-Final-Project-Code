package com.booking.application.backend.service;

import java.util.Map;

import com.booking.application.backend.domain.BankTimeSlot;
import com.booking.application.backend.domain.BankUser;
import com.booking.application.backend.entity.BankTimeslotDetails;

public interface BankUserService {


	Map<String, Object> saveUser(BankUser user);

	Map<String, Object> checkUser(BankUser user);

	Map<String, Object> bookSlot(BankTimeslotDetails timeSlot);
	
	Map<String, Object> updateBooking(BankTimeslotDetails timeSlot);

}
