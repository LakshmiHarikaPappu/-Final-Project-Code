package com.booking.application.backend.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.runner.RunWith;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeMethod;

import com.booking.application.backend.domain.BankHoliday;
import com.booking.application.backend.domain.BankLocation;
import com.booking.application.backend.domain.BankTimeSlot;
import com.booking.application.backend.domain.BankUser;
import com.booking.application.backend.entity.BankLocationDetails;
import com.booking.application.backend.entity.BankTimeslotDetails;
import com.booking.application.backend.repository.BankHolidayRepository;
import com.booking.application.backend.repository.BankLocationRepository;
import com.booking.application.backend.repository.BankTimeSlotRepository;
import com.booking.application.backend.repository.BankUserRepository;
import com.booking.application.backend.service.BankHolidayService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=BankUserServiceImplTest.class)
public class BankUserServiceImplTest {
	
	@InjectMocks
	@Spy
	BankUserServiceImpl classUnderTest = new BankUserServiceImpl();
	
	@Mock
	BankUserRepository userRepository;

	@Mock
	BankTimeSlotRepository timeSlotRepository;

	@Mock
	BankLocationRepository locationRepository;

	@Mock
	BankHolidayRepository holidayRepository;
	
	@BeforeMethod
	void setUp() throws Exception{
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testsaveUser() {
		BankUser user = new BankUser();
		user.setUserName("test");
		when(userRepository.findByUserName(Mockito.any())).thenReturn(Optional.of(user));
		when(userRepository.save(Mockito.any())).thenReturn(user);
		
		Map<String, Object> map = classUnderTest.saveUser(user);
		assertEquals(1, map.size());
	}
	
	@Test
	public void testcheckUser() {
		BankUser user = new BankUser();
		user.setUserName("test");
		user.setPassword("test");
		when(userRepository.findByUserNameAndPassword(Mockito.any(),Mockito.any())).thenReturn(Optional.of(user));		
		Map<String, Object> map = classUnderTest.checkUser(user);
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void tesbookSlot() {
		Date date = Date.valueOf("2022-10-10");
		BankTimeslotDetails timeSlot = new BankTimeslotDetails();
		timeSlot.setBookingDate(date.toString());
		List<BankLocation> locations = new ArrayList<>();
		BankLocation location = new BankLocation();
		locations.add(location);
		when(locationRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(location));
		when(holidayRepository.findAll()).thenReturn(new ArrayList<>());
		when(timeSlotRepository.findByLocationIdAndBookingDateOrderByStartTime(Mockito.anyLong(),Mockito.any())).thenReturn(new ArrayList<>());
		doNothing().when(classUnderTest).sendMail(Mockito.any(),Mockito.any());
		
		Map<String, Object> map = classUnderTest.bookSlot(timeSlot);
		
		assertEquals(1, map.size());
	}
	
}
