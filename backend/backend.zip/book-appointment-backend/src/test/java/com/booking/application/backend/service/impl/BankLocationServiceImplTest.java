package com.booking.application.backend.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeMethod;

import com.booking.application.backend.domain.BankLocation;
import com.booking.application.backend.entity.BankLocationDetails;
import com.booking.application.backend.repository.BankLocationRepository;
import com.booking.application.backend.repository.BankTimeSlotRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=BankLocationServiceImplTest.class)
public class BankLocationServiceImplTest {
	
	@InjectMocks
	@Spy
	BankLocationServiceImpl classUnderTest = new BankLocationServiceImpl();
	
	@Mock
	BankLocationRepository locationRepository;
	
	@Mock
	BankTimeSlotRepository timeSlotRepository;
	
	@BeforeMethod
	void setUp() throws Exception{
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testsaveLocation() {
		List<BankLocation> locations = new ArrayList<>();
		BankLocation location = new BankLocation();
		locations.add(location);
		BankLocationDetails locationDetails = new BankLocationDetails();
		locationDetails.setLocation(location);
		when(locationRepository.save(Mockito.any())).thenReturn(location);
		Map<String, Object> map = classUnderTest.saveLocation(locationDetails);
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void testgetAllLocations() {
		List<BankLocation> locations = new ArrayList<>();
		BankLocation location = new BankLocation();
		locations.add(location);
		when(locationRepository.findAll()).thenReturn(locations);
		
		Map<String, Object> map = classUnderTest.getAllLocations();
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void testDeleteLocation() {
		List<BankLocation> locations = new ArrayList<>();
		BankLocation location = new BankLocation();
		locations.add(location);
		doNothing().when(timeSlotRepository).deleteAllByLocationId(Mockito.any());
		doNothing().when(locationRepository).delete(Mockito.any());
		
		Map<String, Object> map = classUnderTest.deleteLocation(Mockito.anyLong());
		
		assertEquals(0, map.size());
	}
	
}
