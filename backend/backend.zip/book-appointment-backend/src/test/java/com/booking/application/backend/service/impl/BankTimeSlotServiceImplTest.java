package com.booking.application.backend.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.runner.RunWith;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.BeforeMethod;

import com.booking.application.backend.domain.BankLocation;
import com.booking.application.backend.domain.BankTimeSlot;
import com.booking.application.backend.entity.BankLocationDetails;
import com.booking.application.backend.entity.BankTimeslotDetails;
import com.booking.application.backend.repository.BankLocationRepository;
import com.booking.application.backend.repository.BankTimeSlotRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=BankTimeSlotServiceImplTest.class)
public class BankTimeSlotServiceImplTest {
	
	@InjectMocks
	@Spy
	BankTimeSlotServiceImpl classUnderTest = new BankTimeSlotServiceImpl();
	
	@Mock
	BankLocationRepository locationRepository;
	
	
	
	@Mock
	BankTimeSlotRepository timeSlotRepository;
	
	@BeforeMethod
	void setUp() throws Exception{
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testgetHistoryByUserId() {
		when(timeSlotRepository.findByUserId(Mockito.anyLong())).thenReturn(new ArrayList<>());
		when(locationRepository.findAllById(Mockito.anyList())).thenReturn(new ArrayList<>());
		
		Map<String, Object> map = classUnderTest.getHistoryByUserId(1l);
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void testgetHistoryByLocationId() {
		when(timeSlotRepository.findByLocationId(Mockito.anyLong())).thenReturn(new ArrayList<>());
		when(locationRepository.findAllById(Mockito.anyList())).thenReturn(new ArrayList<>());
		
		Map<String, Object> map = classUnderTest.getHistoryByLocationId(1l);
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void testgetAllBooking() {
		when(timeSlotRepository.findAll()).thenReturn(new ArrayList<>());
		when(locationRepository.findAllById(Mockito.anyList())).thenReturn(new ArrayList<>());
		
		Map<String, Object> map = classUnderTest.getHistoryByLocationId(1l);
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void testdeleteAppointment() {
		when(timeSlotRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(new BankTimeSlot()));
		doNothing().when(timeSlotRepository).deleteById(Mockito.anyLong());
		
		Map<String, Object> map = classUnderTest.deleteAppointment(Mockito.anyLong());
		
		assertEquals(1, map.size());
	}
	
	@Test
	public void testgetAvailableTimeslot() {
		Date date = Date.valueOf("2022-10-10");
		BankTimeslotDetails timeSlot = new BankTimeslotDetails();
		timeSlot.setBookingDate(date.toString());
		timeSlot.setLocationId(1l);
		BankLocation location = new BankLocation();
		
		when(timeSlotRepository.findByLocationIdAndAppointmentTypeAndBookingDateOrderByStartTime(Mockito.anyLong(),Mockito.any(),Mockito.any())).thenReturn(new ArrayList<>());
		when(locationRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(location));
		
		Map<String, Object> map = classUnderTest.getAvailableTimeslot(timeSlot);
		
		assertEquals(1, map.size());
		
	}
	
}
